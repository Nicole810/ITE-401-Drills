-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2025 at 03:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime DEFAULT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `staff_id`, `check_in`, `check_out`, `date`) VALUES
(18, 1, '2025-05-24 19:18:34', '2025-05-24 19:18:49', '2025-05-24'),
(19, 1, '2025-05-24 19:18:57', '2025-05-24 19:27:15', '2025-05-24'),
(20, 1, '2025-05-29 15:11:37', '2025-05-29 15:13:20', '2025-05-29'),
(21, 1, '2025-05-29 15:46:04', '2025-05-29 21:23:03', '2025-05-29'),
(22, 1, '2025-05-29 21:23:37', '2025-05-29 21:32:11', '2025-05-29'),
(23, 1, '2025-05-29 21:32:18', '2025-05-29 21:32:23', '2025-05-29'),
(24, 1, '2025-05-29 22:22:07', NULL, '2025-05-29'),
(25, 1, '2025-05-30 08:02:49', '2025-05-30 20:45:04', '2025-05-30'),
(26, 1, '2025-05-30 20:58:03', '2025-05-30 21:03:09', '2025-05-30'),
(27, 1, '2025-05-30 21:04:37', '2025-05-30 21:05:01', '2025-05-30'),
(28, 1, '2025-05-30 21:07:29', '2025-05-30 21:07:37', '2025-05-30'),
(29, 1, '2025-05-30 21:24:49', '2025-05-30 21:27:09', '2025-05-30'),
(30, 1, '2025-05-30 21:28:00', '2025-05-30 21:28:04', '2025-05-30'),
(31, 1, '2025-06-02 16:47:40', '2025-06-02 16:48:21', '2025-06-02'),
(32, 1, '2025-06-02 16:54:39', '2025-06-02 16:56:21', '2025-06-02'),
(33, 1, '2025-06-02 18:19:36', '2025-06-02 18:20:17', '2025-06-02'),
(34, 1, '2025-06-02 18:58:47', '2025-06-02 18:59:02', '2025-06-02'),
(35, 1, '2025-06-02 18:59:37', '2025-06-02 19:06:53', '2025-06-02'),
(36, 1, '2025-06-02 20:14:43', '2025-06-02 20:14:48', '2025-06-02'),
(37, 1, '2025-06-02 21:19:16', '2025-06-02 21:19:39', '2025-06-02'),
(38, 2, '2025-06-02 21:47:02', NULL, '2025-06-02');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `total_cost` float NOT NULL,
  `delivery_option` varchar(20) NOT NULL DEFAULT 'pickup',
  `delivery_location` text DEFAULT NULL,
  `delivery_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'pending',
  `payment_method` varchar(20) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `payment_proof` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `user_id`, `vehicle_id`, `start_date`, `end_date`, `start_time`, `end_time`, `total_cost`, `delivery_option`, `delivery_location`, `delivery_cost`, `status`, `payment_method`, `reference_number`, `payment_proof`, `created_at`, `notes`) VALUES
(7, 13, 3, '2025-06-03', '2025-06-14', '10:00:00', '10:00:00', 28100, 'deliver', 'igbong, barotac nuevo, iloilo', 600.00, 'confirmed', 'gcash', '123445678', 'gcash_Mavimav_20250602.jpg', '2025-06-02 12:55:48', '');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `password` varchar(200) NOT NULL,
  `position` varchar(50) NOT NULL,
  `hire_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `username`, `fullname`, `email`, `phone_number`, `password`, `position`, `hire_date`, `is_active`) VALUES
(1, 'john.doe', 'John Doe', 'john@gmail.com', '+639123456789', 'scrypt:32768:8:1$vmIw2IYvnbPjWAF8$9433e84bba63251d5e75f7b2871702b3fb81def33996cfb4d7fc77c5452b3c1a4c132f195ebcdac3f758c0fc93dbebefe86c601bd52914ba89eba2b9dacde905', 'Manager', '2025-05-22 00:10:10', 1),
(2, 'mgumboc', 'Mj Gumboc', 'mjgumboc@gmail.com', '', 'scrypt:32768:8:1$6P04oL4CChlg4WBA$9457cc1a1f6296de6c6e8b82f37f2d69c9d57a6cf7aa377cc876034f1833a53f7f22f4c07300ba345fd7f4f85dd3ee2f55b94834b5fac8497b47cc91a60e12dc', 'Driver', '2025-06-02 13:46:20', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `password` varchar(200) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_verified` tinyint(1) DEFAULT 0,
  `is_id_verified` tinyint(1) DEFAULT 0,
  `id_image` varchar(255) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `otp_created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `phone_number`, `password`, `role`, `created_at`, `is_verified`, `is_id_verified`, `id_image`, `otp`, `otp_created_at`) VALUES
(13, 'Mavimav', 'mach.dellomes.ui@phinmaed.com', '+639196337971', 'scrypt:32768:8:1$XpW6P0eNkkoB1pZT$1e93ad3c5c708dd359e593d93db2f338aec17fbf388e6835a7d6a94b33f9929ab1f03a18a52165b28b3684d44b8b08150e79d8618fae5728df337a641b9bbb83', 'user', '2025-06-02 04:42:21', 1, 1, 'Mavimav_dellomes_selfie_03-27-25.jpg', NULL, '2025-06-02 12:42:21');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(11) NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `color` varchar(30) NOT NULL,
  `license_plate` varchar(20) NOT NULL,
  `category` varchar(30) NOT NULL,
  `daily_rate` decimal(10,2) NOT NULL,
  `delivery_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_available` tinyint(1) DEFAULT 1,
  `image` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `make`, `model`, `year`, `color`, `license_plate`, `category`, `daily_rate`, `delivery_cost`, `is_available`, `image`, `description`) VALUES
(2, 'Honda', 'CR-V', 2021, 'Blue', 'XYZ789', 'SUV', 2000.00, 600.00, 1, 'uploads/Honda_CR-V_XYZ789.jpg', 'Spacious SUV perfect for family trips'),
(3, 'Toyota', 'Raize', 2023, 'Red', 'ABC-123', 'midsize', 2500.00, 600.00, 0, 'uploads/Toyota_Raize_ABC-123.jpg', '5 seater');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `license_plate` (`license_plate`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
