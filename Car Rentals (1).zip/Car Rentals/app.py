from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import os
import mysql.connector
from dotenv import load_dotenv
from utils.sms import generate_otp, send_otp_via_sms
from utils.validators import validate_phone_number
import pytz
from flask_socketio import SocketIO, emit, join_room


# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your_secret_key')

# MySQL Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+mysqlconnector://{os.getenv('DB_USERNAME')}:{os.getenv('DB_PASSWORD')}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_POOL_RECYCLE'] = 280

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Set timezone for the application
APP_TIMEZONE = pytz.timezone('Asia/Manila')  # Philippines timezone

# Helper function to get current time in the correct timezone
def get_current_time():
    return datetime.now(APP_TIMEZONE)

def get_current_date():
    return datetime.now(APP_TIMEZONE).date()

db = SQLAlchemy(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), unique=True, nullable=True)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')  # 'admin', 'user'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_verified = db.Column(db.Boolean, default=False)
    is_id_verified = db.Column(db.Boolean, default=False)  # New field for ID verification
    id_image = db.Column(db.String(100), nullable=True)  # Path to uploaded ID image
    otp = db.Column(db.String(6), nullable=True)
    otp_created_at = db.Column(db.DateTime, nullable=True)
    bookings = db.relationship('Booking', backref='user', lazy=True)
    reviews = db.relationship('Review', backref='user', lazy=True)

class Staff(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    fullname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), unique=True, nullable=True)
    password = db.Column(db.String(200), nullable=False)
    position = db.Column(db.String(50), nullable=False)
    hire_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    attendance = db.relationship('Attendance', backref='staff', lazy=True)

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    color = db.Column(db.String(30), nullable=False)
    license_plate = db.Column(db.String(20), unique=True, nullable=False)
    category = db.Column(db.String(30), nullable=False)  # 'economy', 'luxury', 'SUV', etc.
    daily_rate = db.Column(db.Float, nullable=False)
    delivery_cost = db.Column(db.Float, nullable=False, default=0.0)  # Cost for vehicle delivery
    is_available = db.Column(db.Boolean, default=True)
    image = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=True)
    bookings = db.relationship('Booking', backref='vehicle', lazy=True)
    reviews = db.relationship('Review', backref='vehicle', lazy=True)

# Booking model with integrated payment fields
class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    total_cost = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'confirmed', 'completed', 'cancelled'
    payment_method = db.Column(db.String(20), nullable=True)  # 'cash', 'gcash'
    reference_number = db.Column(db.String(50), nullable=True)  # For GCash payments
    payment_proof = db.Column(db.String(100), nullable=True)  # Path to uploaded payment proof
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)  # Additional notes for the booking
    delivery_option = db.Column(db.String(20), default='pickup')  # 'pickup', 'deliver'
    delivery_location = db.Column(db.Text, nullable=True)  # Location for delivery if delivery option is selected
    delivery_cost = db.Column(db.Float, nullable=False, default=0.0)  # Cost for delivery

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    staff_id = db.Column(db.Integer, db.ForeignKey('staff.id'), nullable=False)
    check_in = db.Column(db.DateTime, nullable=False, default=get_current_time)
    check_out = db.Column(db.DateTime, nullable=True)
    date = db.Column(db.Date, nullable=False, default=get_current_date)

# Routes
@app.route('/')
def index():
    vehicles = Vehicle.query.filter_by(is_available=True).all()
    return render_template('index.html', vehicles=vehicles)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        raw_phone_number = request.form['phone_number']
        password = request.form['password']
        role = 'user'  # Default role
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists!')
            return redirect(url_for('register'))
        
        # Handle phone number (now optional)
        phone_number = None
        otp = None
        if raw_phone_number.strip():
            # Validate phone number format if provided
            phone_number = validate_phone_number(raw_phone_number)
            if not phone_number:
                flash('Invalid phone number format. Please use a valid format (e.g., +639123456789, 09123456789).')
                return redirect(url_for('register'))
                
            # Check if phone number already exists
            if User.query.filter_by(phone_number=phone_number).first():
                flash('Phone number already registered!')
                return redirect(url_for('register'))
            
            # Generate OTP only if phone number is provided
            otp = generate_otp()
        
        # Handle ID image upload
        id_image_path = None
        if 'id_image' in request.files:
            id_image = request.files['id_image']
            if id_image and id_image.filename:
                # Create directory if it doesn't exist
                upload_dir = os.path.join('uploads', 'id')
                if not os.path.exists(upload_dir):
                    os.makedirs(upload_dir)
                
                # Secure filename and save the file
                filename = f"{username}_{secure_filename(id_image.filename)}"
                id_image.save(os.path.join(upload_dir, filename))
                # Store only the filename, not the path
                id_image_path = filename
        
        # Create user with appropriate verification status
        hashed_password = generate_password_hash(password)
        new_user = User(
            username=username, 
            email=email, 
            phone_number=phone_number,
            password=hashed_password, 
            role=role,
            is_verified=False if phone_number else True,  # Auto-verify phone if no phone number
            is_id_verified=False,  # ID verification requires admin approval
            id_image=id_image_path,
            otp=otp,
            otp_created_at=datetime.utcnow() if otp else None
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        # If phone number provided, proceed with OTP verification
        if phone_number and otp:
            # Send OTP via SMS
            send_otp_via_sms(phone_number, otp)
            
            # Store user_id in session for OTP verification
            session['temp_user_id'] = new_user.id
            
            flash('Registration initiated! Please verify your phone number with the OTP sent.')
            return redirect(url_for('verify_otp'))
        else:
            # Notify user that their account is pending ID verification
            flash('Registration successful! Your account is pending ID verification by an administrator.')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    # Check if user is in verification process
    if 'temp_user_id' not in session:
        flash('Please register first!')
        return redirect(url_for('register'))
        
    # Get user from database
    user = User.query.get(session['temp_user_id'])
    if not user:
        flash('User not found!')
        return redirect(url_for('register'))
        
    # If user has no phone number, they don't need verification
    if not user.phone_number:
        session['user_id'] = user.id
        session.pop('temp_user_id', None)
        flash('Registration successful! Welcome to Car Rental System.')
        return redirect(url_for('index'))
    
    user_id = session['temp_user_id']
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found!')
        session.pop('temp_user_id', None)
        return redirect(url_for('register'))
    
    if request.method == 'POST':
        submitted_otp = request.form['otp']
        
        # Check if OTP is expired (10 minutes validity)
        if user.otp_created_at and datetime.utcnow() - user.otp_created_at > timedelta(minutes=10):
            # Generate new OTP
            new_otp = generate_otp()
            user.otp = new_otp
            user.otp_created_at = datetime.utcnow()
            db.session.commit()
            
            # Send new OTP
            send_otp_via_sms(user.phone_number, new_otp)
            
            flash('OTP expired! A new OTP has been sent to your phone.')
            return redirect(url_for('verify_otp'))
        
        # Verify OTP
        if user.otp == submitted_otp:
            # Mark user as verified
            user.is_verified = True
            user.otp = None  # Clear OTP after verification
            db.session.commit()
            
            # Remove temporary session data
            session.pop('temp_user_id', None)
            
            flash('Phone number verified successfully! Please login.')
            return redirect(url_for('login'))
        else:
            flash('Invalid OTP! Please try again.')
    
    return render_template('verify_otp.html')

@app.route('/resend-otp')
def resend_otp():
    # Check if user is in verification process
    if 'temp_user_id' not in session:
        flash('Please register first!')
        return redirect(url_for('register'))
    
    user_id = session['temp_user_id']
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found!')
        session.pop('temp_user_id', None)
        return redirect(url_for('register'))
    
    # Generate new OTP
    new_otp = generate_otp()
    user.otp = new_otp
    user.otp_created_at = datetime.utcnow()
    db.session.commit()
    
    # Send new OTP
    send_otp_via_sms(user.phone_number, new_otp)
    
    flash('A new verification code has been sent to your phone.')
    return redirect(url_for('verify_otp'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if login is for admin using environment variables
        admin_username = os.getenv('ADMIN_USERNAME')
        admin_password = os.getenv('ADMIN_PASSWORD')
        
        # If credentials match admin environment variables
        if username == admin_username and password == admin_password:
            # Set admin session
            session['user_id'] = 0  # Special ID for env-based admin
            session['username'] = admin_username
            session['role'] = 'admin'
            
            flash(f'Welcome back, {username}!')
            return redirect(url_for('admin_dashboard'))
        
        # First check if it's a staff login
        staff = Staff.query.filter_by(username=username).first()
        
        # If not found by username, try email (for backward compatibility)
        if not staff:
            staff = Staff.query.filter_by(email=username).first()
        
        if staff and staff.is_active:
            try:
                is_password_valid = check_password_hash(staff.password, password)
                if is_password_valid:
                    # Set staff session
                    session['staff_id'] = staff.id
                    session['username'] = staff.fullname
                    session['role'] = 'staff'
                    
                    flash(f'Welcome back, {staff.fullname}!')
                    
                    # Check if already checked in today
                    today = datetime.now().date()
                    existing_attendance = Attendance.query.filter_by(
                        staff_id=staff.id,
                        date=today,
                        check_out=None
                    ).first()
                    
                    # Only create a new attendance record if not already checked in
                    if not existing_attendance:
                        # Check in staff attendance
                        attendance = Attendance(staff_id=staff.id)
                        db.session.add(attendance)
                        db.session.commit()
                        flash('You have been checked in for today.')
                    else:
                        flash(f'Welcome back, {staff.fullname}! You are already checked in for today.')
                    
                    return redirect(url_for('staff_dashboard'))
            except ValueError as e:
                print(f"Password validation error: {e}")
                flash('There was a problem with your password. Please contact an administrator.')
        
        # If not staff, proceed with regular user authentication
        # Check if user exists with the provided username or email
        user = User.query.filter_by(username=username).first()
        
        # If not found by username, try email
        if not user:
            user = User.query.filter_by(email=username).first()
            
        if not user:
            flash('Invalid username/email or password!')
            return render_template('login.html')
            
        # Check if user is verified (phone verification)
        if not user.is_verified and user.role == 'user' and user.phone_number:
            # Store user_id for verification
            session['temp_user_id'] = user.id
            
            # Generate new OTP
            new_otp = generate_otp()
            user.otp = new_otp
            user.otp_created_at = datetime.utcnow()
            db.session.commit()
            
            # Send OTP
            send_otp_via_sms(user.phone_number, new_otp)
            
            flash('Your account is not verified. Please verify with the OTP sent to your phone.')
            return redirect(url_for('verify_otp'))
        
        # Check if user's ID is verified
        if not user.is_id_verified and user.role == 'user':
            flash('Your account is pending ID verification by an administrator. Please check back later.')
            return render_template('login.html')
            
        try:
            is_password_valid = check_password_hash(user.password, password)
            if is_password_valid:
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                
                flash(f'Welcome back, {username}!')
                
                # Redirect based on role
                if user.role == 'admin':
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('index'))
            else:
                flash('Invalid username or password!')
        except ValueError as e:
            # This catches the invalid hash method error
            print(f"Password validation error: {e}")
            flash('There was a problem with your password. Please reset it or contact an administrator.')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    # If user is staff, check out attendance
    if session.get('role') == 'staff':
        # Get staff ID directly from session
        staff_id = session.get('staff_id')
        if staff_id:
            attendance = Attendance.query.filter_by(
                staff_id=staff_id,
                date=datetime.utcnow().date(),
                check_out=None
            ).first()
            
            if attendance:
                attendance.check_out = datetime.now()
                db.session.commit()
                flash('You have been checked out successfully!')
    
    # Clear all session data regardless of user type (database or environment-based)
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    session.pop('staff_id', None)  # Clear staff_id from session
    flash('You have been logged out!')
    return redirect(url_for('index'))

@app.route('/search')
def search():
    query = request.args.get('query', '')
    category = request.args.get('category', '')
    min_price = request.args.get('min_price', 0, type=float)
    max_price = request.args.get('max_price', 1000000, type=float)  # Increased max price default
    
    # Always fetch all vehicles when category=all is specified
    if category == 'all' and not query and not min_price and max_price == 1000000:
        vehicles = Vehicle.query.all()
        return render_template('search_results.html', vehicles=vehicles, query=query)
    
    # Otherwise apply filters
    vehicles = Vehicle.query.filter(Vehicle.is_available == True)
    
    if query:
        vehicles = vehicles.filter(
            (Vehicle.make.ilike(f'%{query}%')) |
            (Vehicle.model.ilike(f'%{query}%')) |
            (Vehicle.description.ilike(f'%{query}%'))
        )
    
    if category and category != 'all':
        vehicles = vehicles.filter(Vehicle.category == category)
    
    vehicles = vehicles.filter(
        Vehicle.daily_rate >= min_price,
        Vehicle.daily_rate <= max_price
    ).all()
    
    return render_template('search_results.html', vehicles=vehicles, query=query)

@app.route('/vehicle/<int:vehicle_id>')
def vehicle_details(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    reviews = Review.query.filter_by(vehicle_id=vehicle_id).all()
    avg_rating = 0
    if reviews:
        avg_rating = sum(review.rating for review in reviews) / len(reviews)
    
    return render_template('vehicle_details.html', vehicle=vehicle, reviews=reviews, avg_rating=avg_rating)

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        flash('Please login to view your profile!')
        return redirect(url_for('login'))
    
    # Get the current user
    user = User.query.get(session['user_id'])
    
    if not user:
        flash('User not found!')
        session.clear()
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Update user information
        user.username = request.form['username']
        user.email = request.form['email']
        user.phone_number = request.form['phone_number']
        
        # Check if password is being updated
        if request.form['password'] and len(request.form['password']) >= 6:
            user.password = generate_password_hash(request.form['password'])
        
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile'))
    
    return render_template('profile.html', user=user)

# Socket.IO event handlers
@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('join_vehicle_room')
def handle_join_vehicle_room(data):
    vehicle_id = data.get('vehicle_id')
    if vehicle_id:
        room = f"vehicle_{vehicle_id}"
        print(f"Client joined room: {room}")
        # Join the room for this specific vehicle
        socketio.join_room(room)

# Function to emit vehicle availability updates
def emit_vehicle_availability_update(vehicle_id):
    vehicle = Vehicle.query.get(vehicle_id)
    if vehicle:
        room = f"vehicle_{vehicle_id}"
        socketio.emit('vehicle_update', {
            'id': vehicle.id,
            'is_available': vehicle.is_available,
            'status': 'Available' if vehicle.is_available else 'Not Available'
        }, room=room)

@app.route('/book/<int:vehicle_id>', methods=['GET', 'POST'])
def book_vehicle(vehicle_id):
    if 'user_id' not in session:
        flash('Please login to book a vehicle!')
        return redirect(url_for('login'))
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    if request.method == 'POST':
        # Get date and time values from form
        start_date = datetime.strptime(request.form['start_date'], '%Y-%m-%d').date()
        end_date = datetime.strptime(request.form['end_date'], '%Y-%m-%d').date()
        start_time = datetime.strptime(request.form['start_time'], '%H:%M').time()
        end_time = datetime.strptime(request.form['end_time'], '%H:%M').time()
        
        # Calculate number of days
        days = (end_date - start_date).days
        if days < 0:
            flash('End date must be after start date!')
            return redirect(url_for('book_vehicle', vehicle_id=vehicle_id))
        elif days == 0 and end_time <= start_time:
            flash('For same-day bookings, end time must be after start time!')
            return redirect(url_for('book_vehicle', vehicle_id=vehicle_id))
        
        # Calculate total cost (consider partial days based on time)
        total_hours = days * 24
        if days > 0:
            # Add hours from the last day
            end_datetime = datetime.combine(end_date, end_time)
            start_datetime = datetime.combine(start_date, start_time)
            total_hours = (end_datetime - start_datetime).total_seconds() / 3600
        
        total_days = total_hours / 24
        total_cost = total_days * vehicle.daily_rate
        
        # Get delivery option and location
        delivery_option = request.form.get('delivery_option', 'pickup')
        delivery_location = ''
        delivery_cost = 0.0
        
        # If delivery option is selected, add delivery cost and get location
        if delivery_option == 'deliver':
            delivery_location = request.form.get('delivery_location', '')
            delivery_cost = vehicle.delivery_cost
            total_cost += delivery_cost
        
        # Get additional notes if provided
        notes = request.form.get('booking_notes', '')
        
        # Get payment method
        payment_method = request.form.get('payment_method', 'cash')
        
        # Create a new booking with integrated payment information
        booking = Booking(
            user_id=session['user_id'],
            vehicle_id=vehicle_id,
            start_date=start_date,
            end_date=end_date,
            start_time=start_time,
            end_time=end_time,
            total_cost=total_cost,
            status='pending',
            payment_method=payment_method,
            notes=notes,
            delivery_option=delivery_option,
            delivery_location=delivery_location,
            delivery_cost=delivery_cost
        )
        
        # If payment method is GCash, handle file upload and reference number
        if payment_method == 'gcash':
            reference_number = request.form.get('reference_number', '')
            booking.reference_number = reference_number
            
            # Handle payment proof upload
            if 'payment_proof' in request.files:
                payment_proof = request.files['payment_proof']
                if payment_proof and payment_proof.filename:
                    # Create directory if it doesn't exist
                    upload_dir = os.path.join('uploads', 'payments')
                    if not os.path.exists(upload_dir):
                        os.makedirs(upload_dir)
                    
                    # Get file extension from original filename
                    file_ext = os.path.splitext(payment_proof.filename)[1]
                    
                    # Get current user's username
                    user = User.query.get(session['user_id'])
                    username = user.username if user else 'unknown'
                    
                    # Generate filename in the format: gcash_username_date
                    current_date = datetime.now().strftime('%Y%m%d')
                    filename = f"gcash_{username}_{current_date}{file_ext}"
                    file_path = os.path.join(upload_dir, filename)
                    
                    # Save the file
                    payment_proof.save(file_path)
                    # Set only the filename in the booking.payment_proof field
                    booking.payment_proof = filename
        
        db.session.add(booking)
        db.session.commit()

        # Send booking confirmation email
        user = User.query.get(session['user_id'])
        if user.email:
            # In a real application, you would use a proper email sending library
            # For demonstration purposes, we'll just log the email content
            print(f"Sending booking confirmation email to {user.email}")
            print(f"Subject: Car Rental Booking Confirmation #{booking.id}")
            print(f"Your booking for {vehicle.make} {vehicle.model} has been received and is pending confirmation.")
            print(f"Booking details:\n")
            
            if delivery_option == 'deliver':
                print(f"- Delivery to: {delivery_location}")
                print(f"- Delivery Cost: ₱{delivery_cost}")
            else:
                print(f"- Pickup: {start_date.strftime('%Y-%m-%d')} at {start_time.strftime('%H:%M')}")
                
            print(f"- Return: {end_date.strftime('%Y-%m-%d')} at {end_time.strftime('%H:%M')}")
            print(f"- Total Cost: ₱{total_cost}")
            print(f"- Payment Method: {payment_method.capitalize()}")
            print(f"- Status: {booking.status}")
            
            # In a production environment, you would implement actual email sending here
            # Example: send_email(user.email, subject, message)
        
        flash('Booking submitted! Your booking is pending staff confirmation. A confirmation email has been sent to your registered email address.')
        return redirect(url_for('user_bookings'))
    
    today = datetime.now().strftime('%Y-%m-%d')
    return render_template('book_vehicle.html', vehicle=vehicle, today=today)

@app.route('/user/bookings')
def user_bookings():
    if 'user_id' not in session:
        flash('Please login to view your bookings!')
        return redirect(url_for('login'))
    
    # Get all bookings for the current user
    bookings = Booking.query.filter_by(user_id=session['user_id']).all()
    return render_template('user_bookings.html', bookings=bookings)

@app.route('/user/booking/cancel/<int:booking_id>')
def user_cancel_booking(booking_id):
    if 'user_id' not in session:
        flash('Please login to cancel a booking!')
        return redirect(url_for('login'))
    
    # Get the booking and verify it belongs to the current user
    booking = Booking.query.get_or_404(booking_id)
    
    if booking.user_id != session['user_id']:
        flash('Unauthorized access!')
        return redirect(url_for('user_bookings'))
    
    # Only allow cancellation of pending bookings
    if booking.status != 'pending':
        flash('Only pending bookings can be cancelled!')
        return redirect(url_for('user_bookings'))
    
    # Update booking status to cancelled
    booking.status = 'cancelled'
    
    # Make vehicle available again
    vehicle = Vehicle.query.get(booking.vehicle_id)
    if vehicle:
        vehicle.is_available = True
        # Emit vehicle availability update
        emit_vehicle_availability_update(vehicle.id)
    
    db.session.commit()
    
    flash('Your booking has been cancelled successfully!')
    return redirect(url_for('user_bookings'))

@app.route('/review/<int:vehicle_id>', methods=['GET', 'POST'])
def review_vehicle(vehicle_id):
    if 'user_id' not in session:
        flash('Please login to review a vehicle!')
        return redirect(url_for('login'))
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # Check if user has booked this vehicle before
    booking = Booking.query.filter_by(
        user_id=session['user_id'],
        vehicle_id=vehicle_id,
        status='completed'
    ).first()
    
    if not booking:
        flash('You can only review vehicles you have rented!')
        return redirect(url_for('vehicle_details', vehicle_id=vehicle_id))
    
    if request.method == 'POST':
        rating = int(request.form['rating'])
        comment = request.form['comment']
        
        # Check if user has already reviewed this vehicle
        existing_review = Review.query.filter_by(
            user_id=session['user_id'],
            vehicle_id=vehicle_id
        ).first()
        
        if existing_review:
            existing_review.rating = rating
            existing_review.comment = comment
        else:
            review = Review(
                user_id=session['user_id'],
                vehicle_id=vehicle_id,
                rating=rating,
                comment=comment
            )
            db.session.add(review)
        
        db.session.commit()
        flash('Review submitted!')
        return redirect(url_for('vehicle_details', vehicle_id=vehicle_id))
    
    return render_template('review_vehicle.html', vehicle=vehicle)

# Admin routes
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    vehicles = Vehicle.query.all()
    users = User.query.all()
    bookings = Booking.query.all()
    staff = User.query.filter_by(role='staff').all()
    
    # Get pending users (users with ID verification pending)
    pending_users = User.query.filter_by(is_id_verified=False, role='user').all()
    
    # Counts for dashboard cards
    vehicles_count = len(vehicles)
    users_count = len(users)
    bookings_count = len(bookings)
    staff_count = len(staff)
    pending_users_count = len(pending_users)
    
    # Add admin environment info for the template
    admin_info = {
        'username': os.getenv('ADMIN_USERNAME'),
        'is_env_admin': session.get('user_id') == 0  # Flag to identify env-based admin
    }
    
    return render_template('admin/dashboard.html', 
                           vehicles=vehicles, 
                           users=users, 
                           bookings=bookings, 
                           vehicles_count=vehicles_count,
                           users_count=users_count,
                           bookings_count=bookings_count,
                           staff_count=staff_count,
                           pending_users_count=pending_users_count,
                           staff=staff,
                           pending_users=pending_users,
                           admin_info=admin_info,
                           now=datetime.now)

@app.route('/admin/vehicles')
def admin_vehicles():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    vehicles = Vehicle.query.all()
    return render_template('admin/vehicles.html', vehicles=vehicles, admin_info={'is_env_admin': session.get('user_id') == 0})

@app.route('/admin/vehicle/add', methods=['GET', 'POST'])
def admin_add_vehicle():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    if request.method == 'POST':
        make = request.form['make']
        model = request.form['model']
        year = int(request.form['year'])
        color = request.form['color']
        license_plate = request.form['license_plate']
        category = request.form['category']
        daily_rate = float(request.form['daily_rate'])
        delivery_cost = float(request.form['delivery_cost'])
        description = request.form['description']
        
        # Handle image upload
        image = ''
        if 'image' in request.files:
            file = request.files['image']
            if file.filename != '':
                filename = f"{make}_{model}_{license_plate}.jpg"
                file.save(os.path.join(app.static_folder, 'uploads', filename))
                image = f"uploads/{filename}"
        
        vehicle = Vehicle(
            make=make,
            model=model,
            year=year,
            color=color,
            license_plate=license_plate,
            category=category,
            daily_rate=daily_rate,
            delivery_cost=delivery_cost,
            description=description,
            image=image
        )
        
        db.session.add(vehicle)
        db.session.commit()
        
        flash('Vehicle added successfully!')
        return redirect(url_for('admin_vehicles'))
    
    return render_template('admin/add_vehicle.html', admin_info=admin_info)

@app.route('/admin/vehicle/edit/<int:vehicle_id>', methods=['GET', 'POST'])
def admin_edit_vehicle(vehicle_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    if request.method == 'POST':
        vehicle.make = request.form['make']
        vehicle.model = request.form['model']
        vehicle.year = int(request.form['year'])
        vehicle.color = request.form['color']
        vehicle.license_plate = request.form['license_plate']
        vehicle.category = request.form['category']
        vehicle.daily_rate = float(request.form['daily_rate'])
        vehicle.delivery_cost = float(request.form['delivery_cost'])
        vehicle.description = request.form['description']
        
        # Check if availability has changed
        new_availability = 'is_available' in request.form
        if vehicle.is_available != new_availability:
            vehicle.is_available = new_availability
            # Emit vehicle availability update
            emit_vehicle_availability_update(vehicle.id)
        else:
            vehicle.is_available = new_availability
        
        # Handle image upload
        if 'image' in request.files:
            file = request.files['image']
            if file.filename != '':
                filename = f"{vehicle.make}_{vehicle.model}_{vehicle.license_plate}.jpg"
                file.save(os.path.join(app.static_folder, 'uploads', filename))
                vehicle.image = f"uploads/{filename}"
        
        db.session.commit()
        flash('Vehicle updated successfully!')
        return redirect(url_for('admin_vehicles'))
    
    return render_template('admin/edit_vehicle.html', vehicle=vehicle, admin_info=admin_info)

@app.route('/admin/vehicle/delete/<int:vehicle_id>')
def admin_delete_vehicle(vehicle_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Environment-based admin can perform all operations
    # No need to check database credentials
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # Delete associated bookings and reviews
    Booking.query.filter_by(vehicle_id=vehicle_id).delete()
    Review.query.filter_by(vehicle_id=vehicle_id).delete()
    
    # Delete the vehicle
    db.session.delete(vehicle)
    db.session.commit()
    
    flash('Vehicle deleted successfully!')
    return redirect(url_for('admin_vehicles'))

@app.route('/admin/users')
def admin_users():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    users = User.query.all()
    return render_template('admin/users.html', users=users, admin_info=admin_info)

@app.route('/admin/pending-users')
def admin_pending_users():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    # Get users with pending ID verification
    pending_users = User.query.filter_by(is_id_verified=False, role='user').all()
    return render_template('admin/pending_users.html', users=pending_users, admin_info=admin_info)

@app.route('/admin/user/edit/<int:user_id>', methods=['GET', 'POST'])
def admin_edit_user(user_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        user.username = request.form['username']
        user.email = request.form['email']
        user.role = request.form['role']
        
        # Handle ID verification if checkbox is checked
        if 'verify_id' in request.form:
            user.is_id_verified = True
            flash('User ID has been verified!')
        
        if request.form['password']:
            user.password = generate_password_hash(request.form['password'])
        
        db.session.commit()
        
        flash('User updated successfully!')
        return redirect(url_for('admin_users'))
    
    return render_template('admin/edit_user.html', user=user, admin_info=admin_info)

@app.route('/admin/user/verify/<int:user_id>')
def admin_verify_user(user_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    user = User.query.get_or_404(user_id)
    
    # Verify the user's ID
    user.is_id_verified = True
    db.session.commit()
    
    flash(f'User {user.username} has been verified successfully!')
    return redirect(url_for('admin_pending_users'))

@app.route('/admin/bookings')
def admin_bookings():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    bookings = Booking.query.all()
    
    # Add start_datetime and end_datetime attributes to each booking
    for booking in bookings:
        booking.start_datetime = datetime.combine(booking.start_date, booking.start_time)
        booking.end_datetime = datetime.combine(booking.end_date, booking.end_time)
    
    return render_template('admin/bookings.html', bookings=bookings, admin_info=admin_info)

@app.route('/admin/booking/update/<int:booking_id>', methods=['POST'])
def admin_update_booking(booking_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Environment-based admin can perform all operations
    # No need to check database credentials
    
    booking = Booking.query.get_or_404(booking_id)
    new_status = request.form['status']
    old_status = booking.status
    
    booking.status = new_status
    
    # If booking is being confirmed, make vehicle unavailable
    if old_status == 'pending' and new_status == 'confirmed':
        vehicle = Vehicle.query.get(booking.vehicle_id)
        if vehicle:
            vehicle.is_available = False
            # Emit vehicle availability update
            emit_vehicle_availability_update(vehicle.id)
    
    # If booking is completed or cancelled, make vehicle available again
    if new_status in ['completed', 'cancelled']:
        vehicle = Vehicle.query.get(booking.vehicle_id)
        if vehicle:
            vehicle.is_available = True
            # Emit vehicle availability update
            emit_vehicle_availability_update(vehicle.id)
    
    db.session.commit()
    
    flash('Booking status updated!')
    return redirect(url_for('admin_bookings'))



@app.route('/admin/staff')
def admin_staff():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Pass admin info to template
    admin_info = {'is_env_admin': session.get('user_id') == 0}
    
    staff_list = Staff.query.all()
    return render_template('admin/staff.html', staff=staff_list, admin_info=admin_info)

@app.route('/admin/staff/add', methods=['POST'])
def admin_add_staff():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get form data
    fullname = request.form.get('fullname')
    username = request.form.get('username')
    email = request.form.get('email')
    phone_number = request.form.get('phone_number')
    password = request.form.get('password')
    position = request.form.get('position')
    
    # Generate username from fullname if not provided
    if not username or username.strip() == '':
        # Create username from fullname (first letter of first name + last name)
        name_parts = fullname.split()
        if len(name_parts) > 1:
            username = (name_parts[0][0] + name_parts[-1]).lower()
        else:
            username = name_parts[0].lower()
        
        # Ensure username is unique
        base_username = username
        counter = 1
        while Staff.query.filter_by(username=username).first():
            username = f"{base_username}{counter}"
            counter += 1
    
    # Validate required fields
    if not fullname or not email or not password or not position:
        flash('All required fields must be filled!')
        return redirect(url_for('admin_staff'))
    
    # Check if username or email already exists
    if Staff.query.filter_by(username=username).first():
        flash('Username already exists!')
        return redirect(url_for('admin_staff'))
        
    if Staff.query.filter_by(email=email).first():
        flash('Email already exists!')
        return redirect(url_for('admin_staff'))
    
    if User.query.filter_by(email=email).first():
        flash('Email already exists!')
        return redirect(url_for('admin_staff'))
    
    # Validate phone number if provided
    if phone_number and phone_number.strip():
        phone_number = validate_phone_number(phone_number)
        if not phone_number:
            flash('Invalid phone number format!')
            return redirect(url_for('admin_staff'))
            
        # Check if phone number already exists
        if User.query.filter_by(phone_number=phone_number).first() or Staff.query.filter_by(phone_number=phone_number).first():
            flash('Phone number already registered!')
            return redirect(url_for('admin_staff'))
    
    # Create staff record directly
    hashed_password = generate_password_hash(password)
    new_staff = Staff(
        username=username,
        fullname=fullname,
        email=email,
        phone_number=phone_number,
        password=hashed_password,
        position=position,
        is_active=True
    )
    
    db.session.add(new_staff)
    db.session.commit()
    
    flash('Staff member added successfully!')
    return redirect(url_for('admin_staff'))

@app.route('/admin/staff/edit/<int:staff_id>', methods=['POST'])
def admin_edit_staff(staff_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    staff = Staff.query.get_or_404(staff_id)
    fullname = request.form.get('fullname')
    username = request.form.get('username')
    position = request.form.get('position')
    is_active = 'is_active' in request.form
    
    if not position or not fullname or not username:
        flash('Full name, username, and position are required!')
        return redirect(url_for('admin_staff'))
    
    # Check if username is already taken by another staff member
    existing_staff = Staff.query.filter_by(username=username).first()
    if existing_staff and existing_staff.id != staff_id:
        flash('Username already exists!')
        return redirect(url_for('admin_staff'))
    
    staff.fullname = fullname
    staff.username = username
    staff.position = position
    staff.is_active = is_active
    db.session.commit()
    
    flash('Staff member updated successfully!')
    return redirect(url_for('admin_staff'))

@app.route('/admin/staff/delete/<int:staff_id>', methods=['POST'])
def admin_delete_staff(staff_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    staff = Staff.query.get_or_404(staff_id)
    
    # Delete associated attendance records
    Attendance.query.filter_by(staff_id=staff_id).delete()
    
    # Delete staff record
    db.session.delete(staff)
    db.session.commit()
    
    flash('Staff member removed successfully!')
    return redirect(url_for('admin_staff'))

@app.route('/admin/staff/attendance')
def admin_staff_attendance():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    admin_info = User.query.get(session['user_id'])
    staff_list = Staff.query.all()
    attendance = Attendance.query.order_by(Attendance.date.desc()).all()
    
    return render_template('admin/staff_attendance.html', staff=staff_list, attendance=attendance, now=get_current_time, admin_info=admin_info)

# Staff routes
@app.route('/staff/dashboard')
def staff_dashboard():
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    # Get current attendance record
    today = datetime.now().date()
    current_attendance = Attendance.query.filter_by(
        staff_id=staff_record.id,
        date=today,
        check_out=None
    ).first()
    
    # Get all attendance records for this staff member
    attendance_records = Attendance.query.filter_by(staff_id=staff_record.id).all()
    
    # Get all bookings
    bookings = Booking.query.all()
    
    # Get all vehicles
    vehicles = Vehicle.query.all()
    
    return render_template('staff/dashboard.html', 
                           staff=staff_record, 
                           attendance=attendance_records,
                           bookings=bookings, 
                           vehicles=vehicles,
                           now=datetime.now)

@app.route('/staff/attendance')
def staff_attendance():
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    # Get all attendance records for this staff member
    attendance_records = Attendance.query.filter_by(staff_id=staff_record.id).order_by(Attendance.date.desc()).all()
    
    return render_template('staff/attendance.html', attendance=attendance_records, now=get_current_time)

@app.route('/staff/check-in', methods=['POST'])
def staff_check_in():
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    # Check if already checked in today
    today = get_current_date()
    existing_record = Attendance.query.filter_by(
        staff_id=staff_record.id,
        date=today
    ).first()
    
    if existing_record:
        flash('You have already checked in today!')
    else:
        new_attendance = Attendance(
            staff_id=staff_record.id,
            date=today,
            check_in=get_current_time()
        )
        db.session.add(new_attendance)
        db.session.commit()
        flash('Check-in successful!')
    
    return redirect(url_for('staff_attendance'))

@app.route('/staff/check-out', methods=['POST'])
def staff_check_out():
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    # Find today's attendance record
    today = get_current_date()
    attendance_record = Attendance.query.filter_by(
        staff_id=staff_record.id,
        date=today
    ).first()
    
    if not attendance_record:
        flash('You have not checked in today!')
    elif attendance_record.check_out:
        flash('You have already checked out today!')
    else:
        attendance_record.check_out = get_current_time()
        db.session.commit()
        flash('Check-out successful!')
    
    return redirect(url_for('staff_attendance'))

@app.route('/staff/bookings')
def staff_bookings():
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    bookings = Booking.query.all()
    return render_template('staff/bookings.html', bookings=bookings, now=datetime.now)

@app.route('/staff/booking/update/<int:booking_id>', methods=['POST'])
def staff_update_booking(booking_id):
    if 'staff_id' not in session or session['role'] != 'staff':
        flash('Unauthorized access!')
        return redirect(url_for('index'))
    
    # Get staff record directly using staff_id from session
    staff_record = Staff.query.get(session['staff_id'])
    
    if not staff_record:
        flash('Staff record not found!')
        return redirect(url_for('index'))
    
    booking = Booking.query.get_or_404(booking_id)
    new_status = request.form.get('status')
    old_status = booking.status
    
    booking.status = new_status
    
    # If booking is being confirmed, make vehicle unavailable
    if old_status == 'pending' and new_status == 'confirmed':
        vehicle = Vehicle.query.get(booking.vehicle_id)
        if vehicle:
            vehicle.is_available = False
            # Emit vehicle availability update
            emit_vehicle_availability_update(vehicle.id)
    
    # If booking is completed or cancelled, make vehicle available again
    if new_status in ['completed', 'cancelled']:
        vehicle = Vehicle.query.get(booking.vehicle_id)
        if vehicle:
            vehicle.is_available = True
            # Emit vehicle availability update
            emit_vehicle_availability_update(vehicle.id)
    
    db.session.commit()
    
    flash('Booking status updated!')
    return redirect(url_for('staff_bookings'))



# Context processor to make staff data available to all templates
@app.context_processor
def inject_staff_data():
    context = {}
    if session.get('role') == 'staff' and session.get('staff_id'):
        staff = Staff.query.get(session.get('staff_id'))
        if staff:
            context['staff'] = staff
            
            # Get current attendance record
            today = datetime.now().date()
            attendance = Attendance.query.filter_by(
                staff_id=staff.id,
                date=today,
                check_out=None
            ).first()
            context['attendance'] = attendance
    
    # Get pending users count for admin navigation
    if session.get('role') == 'admin':
        pending_users_count = User.query.filter_by(is_id_verified=False, role='user').count()
        context['pending_users_count'] = pending_users_count
    
    return context

# Create database tables
with app.app_context():
    db.create_all()
    
    # Check if we need to migrate existing staff users to the new Staff model
    # This is a one-time migration for existing staff users
    try:
        staff_users = User.query.filter_by(role='staff').all()
        migrated_count = 0
        for user in staff_users:
            # Check if this user already has a staff record
            existing_staff = Staff.query.filter_by(user_id=user.id).first()
            if not existing_staff:
                # Create a new staff record for this user
                new_staff = Staff(
                    user_id=user.id,
                    position='Staff Member',  # Default position
                    hire_date=user.created_at  # Use user creation date as hire date
                )
                db.session.add(new_staff)
                migrated_count += 1
        
        # Commit all changes
        db.session.commit()
        if migrated_count > 0:
            print(f'Staff migration completed successfully! Migrated {migrated_count} staff members.')
    except Exception as e:
        print(f'Error during staff migration: {str(e)}')
        db.session.rollback()
    
# Route to serve files from the uploads directory
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    # Check if the filename contains a directory path
    if '/' in filename:
        # Split the path to get the directory and the actual filename
        directory, actual_filename = filename.split('/', 1)
        return send_from_directory(os.path.join('uploads', directory), actual_filename)
    
    # For direct filenames
    return send_from_directory('uploads', filename)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    socketio.run(app, debug=True)