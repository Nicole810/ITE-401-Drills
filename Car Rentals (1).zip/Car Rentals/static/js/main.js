/**
     * RR Car Rental - Main JavaScript File
     */

    document.addEventListener('DOMContentLoaded', function() {
        // Add data-aos attributes to elements for animations
        addAOSAttributes();
        
        // Initialize tooltips
        initTooltips();
        
        // Initialize vehicle image gallery if on vehicle details page
        initVehicleGallery();
        
        // Add active class to current nav item
        highlightCurrentNavItem();
        
        // Initialize date pickers with validation
        initDatePickers();
        
        // Ensure modals are appended to body for proper positioning
        fixModalPositioning();
    });

    /**
     * Add AOS (Animate On Scroll) attributes to elements
     */
    function addAOSAttributes() {
        // Add fade-up animation to cards
        document.querySelectorAll('.card').forEach(function(card, index) {
            if (!card.hasAttribute('data-aos')) {
                card.setAttribute('data-aos', 'fade-up');
                card.setAttribute('data-aos-delay', (index % 3) * 80 + '');
                card.setAttribute('data-aos-duration', '600');
            }
        });
        
        // Add fade-right animation to section headings
        document.querySelectorAll('h2, h3').forEach(function(heading) {
            if (!heading.hasAttribute('data-aos') && !heading.closest('.card-header')) {
                heading.setAttribute('data-aos', 'fade-right');
                heading.setAttribute('data-aos-duration', '500');
            }
        });
        
        // Add fade-in animation to images
        document.querySelectorAll('.img-fluid').forEach(function(img) {
            if (!img.hasAttribute('data-aos')) {
                img.setAttribute('data-aos', 'fade-in');
                img.setAttribute('data-aos-duration', '600');
            }
        });
    }

    /**
     * Initialize Bootstrap tooltips
     */
    function initTooltips() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    /**
     * Initialize vehicle image gallery with lightbox effect
     */
    function initVehicleGallery() {
        const vehicleImages = document.querySelectorAll('.vehicle-gallery img');
        
        if (vehicleImages.length > 0) {
            vehicleImages.forEach(function(img) {
                img.addEventListener('click', function() {
                    Swal.fire({
                        imageUrl: img.src,
                        imageAlt: img.alt,
                        showCloseButton: true,
                        showConfirmButton: false,
                        width: 'auto',
                        padding: '1em',
                        background: '#fff',
                        backdrop: `rgba(0,0,0,0.8)`
                    });
                });
            });
        }
    }

    /**
     * Highlight current navigation item based on URL
     */
    function highlightCurrentNavItem() {
        const currentPath = window.location.pathname;
        
        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            const href = link.getAttribute('href');
            
            // Skip dropdown toggle links
            if (link.classList.contains('dropdown-toggle')) return;
            
            // Check if the link's href matches the current path
            if (href && currentPath === href) {
                link.classList.add('active');
            } else if (href && currentPath.includes(href) && href !== '/') {
                // For nested paths, highlight parent if it's not the home page
                link.classList.add('active');
            }
        });
    }

    /**
     * Initialize date pickers with validation for booking forms
     */
    function initDatePickers() {
        const pickupDateInput = document.getElementById('pickup_date');
        const returnDateInput = document.getElementById('return_date');
        
        if (pickupDateInput && returnDateInput) {
            // Set minimum date to today
            const today = new Date().toISOString().split('T')[0];
            pickupDateInput.setAttribute('min', today);
            returnDateInput.setAttribute('min', today);
            
            // Update return date min value when pickup date changes
            pickupDateInput.addEventListener('change', function() {
                returnDateInput.setAttribute('min', this.value);
                
                // If return date is before pickup date, update it
                if (returnDateInput.value && returnDateInput.value < this.value) {
                    returnDateInput.value = this.value;
                }
            });
        }
    }

    /**
     * Fix modal positioning by appending all modals to the body element
     * This ensures modals display correctly regardless of their original position in the DOM
     */
    function fixModalPositioning() {
        // Check if jQuery is available
        if (typeof jQuery !== 'undefined') {
            // Append all Bootstrap modals to the body element
            $('.modal').appendTo('body');
        }
    }

    /**
     * Calculate rental price based on selected dates
     * @param {number} dailyRate - The daily rate for the vehicle
     * @param {string} pickupDate - Pickup date string
     * @param {string} returnDate - Return date string
     * @returns {number} - Total rental price
     */
    function calculateRentalPrice(dailyRate, pickupDate, returnDate) {
        if (!pickupDate || !returnDate || !dailyRate) return 0;
        
        const pickup = new Date(pickupDate);
        const returnD = new Date(returnDate);
        
        // Calculate difference in days
        const diffTime = Math.abs(returnD - pickup);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        // Ensure at least 1 day
        const days = Math.max(1, diffDays);
        
        return dailyRate * days;
    }

    /**
     * Update price calculation in the booking form
     */
    function updatePriceCalculation() {
        const pickupDateInput = document.getElementById('pickup_date');
        const returnDateInput = document.getElementById('return_date');
        const dailyRateElement = document.getElementById('daily_rate');
        const totalPriceElement = document.getElementById('total_price');
        
        if (pickupDateInput && returnDateInput && dailyRateElement && totalPriceElement) {
            const dailyRate = parseFloat(dailyRateElement.textContent.replace(/[^0-9.]/g, ''));
            const total = calculateRentalPrice(dailyRate, pickupDateInput.value, returnDateInput.value);
            
            if (total > 0) {
                totalPriceElement.textContent = '₱' + total.toFixed(2);
            }
        }
    }

    // Add event listeners for booking form price calculation
    document.addEventListener('DOMContentLoaded', function() {
        const pickupDateInput = document.getElementById('pickup_date');
        const returnDateInput = document.getElementById('return_date');
        
        if (pickupDateInput && returnDateInput) {
            pickupDateInput.addEventListener('change', updatePriceCalculation);
            returnDateInput.addEventListener('change', updatePriceCalculation);
        }
    });


