import re

def validate_phone_number(phone_number):
    """
    Validate phone number format
    Accepts formats like: +639123456789, 09123456789, 9123456789
    Returns a standardized format with country code
    """
    # Remove any non-digit characters except the + sign at the beginning
    cleaned = re.sub(r'[^\d+]', '', phone_number)
    
    # Check if it's a valid Philippine number
    # Format 1: +639XXXXXXXXX (international format with country code)
    # Format 2: 09XXXXXXXXX (local format with leading 0)
    # Format 3: 9XXXXXXXXX (local format without leading 0)
    
    if re.match(r'^\+639\d{9}$', cleaned):
        # Already in the correct format
        return cleaned
    elif re.match(r'^09\d{9}$', cleaned):
        # Convert 09XXXXXXXXX to +639XXXXXXXXX
        return '+63' + cleaned[1:]
    elif re.match(r'^9\d{9}$', cleaned):
        # Convert 9XXXXXXXXX to +639XXXXXXXXX
        return '+63' + cleaned
    else:
        # Invalid format
        return None